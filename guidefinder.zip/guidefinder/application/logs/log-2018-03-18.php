<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-18 06:40:41 --> No URI present. Default controller set.
DEBUG - 2018-03-18 11:56:56 --> No URI present. Default controller set.
DEBUG - 2018-03-18 11:57:10 --> No URI present. Default controller set.
ERROR - 2018-03-18 12:11:14 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:11:14 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:11:14 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:11:14 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:11:14 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:11:14 --> 404 Page Not Found: Services/css
ERROR - 2018-03-18 12:11:14 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:11:14 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:21:07 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2018-03-18 12:21:08 --> 404 Page Not Found: Css/sb-admin.css
ERROR - 2018-03-18 12:21:08 --> 404 Page Not Found: Vendor/font-awesome
ERROR - 2018-03-18 12:21:08 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:21:08 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:21:08 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:21:08 --> 404 Page Not Found: Vendor/font-awesome
ERROR - 2018-03-18 12:21:08 --> 404 Page Not Found: Css/sb-admin.css
ERROR - 2018-03-18 12:21:08 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:21:09 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:21:09 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:43:36 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:43:36 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:43:36 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:43:37 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:43:37 --> 404 Page Not Found: Services/vendor
ERROR - 2018-03-18 12:43:37 --> 404 Page Not Found: Services/vendor
DEBUG - 2018-03-18 14:22:04 --> No URI present. Default controller set.
ERROR - 2018-03-18 14:22:08 --> 404 Page Not Found: Signup/index
DEBUG - 2018-03-18 14:22:14 --> No URI present. Default controller set.
ERROR - 2018-03-18 14:22:28 --> 404 Page Not Found: Services/login
ERROR - 2018-03-18 14:22:45 --> 404 Page Not Found: Services/login
ERROR - 2018-03-18 14:22:50 --> 404 Page Not Found: Services/login
ERROR - 2018-03-18 14:22:56 --> 404 Page Not Found: Services/login
ERROR - 2018-03-18 14:23:07 --> 404 Page Not Found: Services/login
ERROR - 2018-03-18 14:23:17 --> 404 Page Not Found: Services/login
ERROR - 2018-03-18 14:28:07 --> 404 Page Not Found: Services/login
ERROR - 2018-03-18 14:28:29 --> 404 Page Not Found: Services/login
DEBUG - 2018-03-18 14:29:57 --> No URI present. Default controller set.
ERROR - 2018-03-18 14:30:04 --> 404 Page Not Found: Services/login
ERROR - 2018-03-18 14:32:43 --> 404 Page Not Found: Services/login
ERROR - 2018-03-18 14:35:14 --> 404 Page Not Found: Services/login
ERROR - 2018-03-18 14:36:07 --> 404 Page Not Found: Services/index.php
ERROR - 2018-03-18 14:36:11 --> 404 Page Not Found: Services/forgot-password.php
ERROR - 2018-03-18 14:36:16 --> 404 Page Not Found: Services/register.php
ERROR - 2018-03-18 14:40:43 --> 404 Page Not Found: Services/register.php
ERROR - 2018-03-18 14:40:49 --> 404 Page Not Found: Services/register.php
ERROR - 2018-03-18 14:42:04 --> 404 Page Not Found: Services/login.php
ERROR - 2018-03-18 14:43:07 --> 404 Page Not Found: Services/login.php
DEBUG - 2018-03-18 15:43:26 --> No URI present. Default controller set.
DEBUG - 2018-03-18 16:22:21 --> No URI present. Default controller set.
DEBUG - 2018-03-18 16:22:24 --> No URI present. Default controller set.
DEBUG - 2018-03-18 16:27:29 --> No URI present. Default controller set.
ERROR - 2018-03-18 16:49:00 --> 404 Page Not Found: Services/services
DEBUG - 2018-03-18 19:27:33 --> No URI present. Default controller set.
