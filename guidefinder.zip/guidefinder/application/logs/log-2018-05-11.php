<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-05-11 06:55:59 --> No URI present. Default controller set.
DEBUG - 2018-05-11 07:12:27 --> No URI present. Default controller set.
DEBUG - 2018-05-11 08:15:40 --> No URI present. Default controller set.
DEBUG - 2018-05-11 10:04:36 --> No URI present. Default controller set.
DEBUG - 2018-05-11 10:20:34 --> No URI present. Default controller set.
DEBUG - 2018-05-11 10:43:49 --> No URI present. Default controller set.
DEBUG - 2018-05-11 11:16:09 --> No URI present. Default controller set.
DEBUG - 2018-05-11 11:59:58 --> No URI present. Default controller set.
DEBUG - 2018-05-11 17:27:47 --> No URI present. Default controller set.
