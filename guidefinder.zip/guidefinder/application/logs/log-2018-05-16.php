<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-05-16 05:41:27 --> No URI present. Default controller set.
ERROR - 2018-05-16 07:25:10 --> 404 Page Not Found: Guide/tables.php
ERROR - 2018-05-16 07:26:50 --> 404 Page Not Found: Guide/tables.php
ERROR - 2018-05-16 07:44:11 --> 404 Page Not Found: Guide/tables.php
ERROR - 2018-05-16 09:00:16 --> 404 Page Not Found: Guide/tables.php
ERROR - 2018-05-16 09:22:38 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp64\www\guidefinder\application\views\guide\tables.php 165
ERROR - 2018-05-16 09:22:38 --> Severity: Notice --> Undefined variable: name C:\wamp64\www\guidefinder\application\views\guide\tables.php 167
ERROR - 2018-05-16 09:22:38 --> Severity: Notice --> Undefined variable: email C:\wamp64\www\guidefinder\application\views\guide\tables.php 167
ERROR - 2018-05-16 09:22:38 --> Severity: Notice --> Undefined variable: phone C:\wamp64\www\guidefinder\application\views\guide\tables.php 167
ERROR - 2018-05-16 09:22:38 --> Severity: Notice --> Undefined variable: service_id C:\wamp64\www\guidefinder\application\views\guide\tables.php 167
ERROR - 2018-05-16 09:22:38 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:38 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:38 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:38 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:38 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:38 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:38 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:38 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:38 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 09:22:38 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 09:22:38 --> 404 Page Not Found: Guide/css
ERROR - 2018-05-16 09:22:38 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:38 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:38 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:38 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:38 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:38 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 09:22:39 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 09:22:42 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp64\www\guidefinder\application\views\guide\tables.php 165
ERROR - 2018-05-16 09:22:42 --> Severity: Notice --> Undefined variable: name C:\wamp64\www\guidefinder\application\views\guide\tables.php 167
ERROR - 2018-05-16 09:22:42 --> Severity: Notice --> Undefined variable: email C:\wamp64\www\guidefinder\application\views\guide\tables.php 167
ERROR - 2018-05-16 09:22:42 --> Severity: Notice --> Undefined variable: phone C:\wamp64\www\guidefinder\application\views\guide\tables.php 167
ERROR - 2018-05-16 09:22:42 --> Severity: Notice --> Undefined variable: service_id C:\wamp64\www\guidefinder\application\views\guide\tables.php 167
ERROR - 2018-05-16 09:22:42 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:42 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:42 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:42 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:43 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:43 --> 404 Page Not Found: Guide/css
ERROR - 2018-05-16 09:22:43 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:43 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:43 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:43 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 09:22:43 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 09:22:43 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:43 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:43 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:43 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:43 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:22:43 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 09:22:43 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 09:24:55 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp64\www\guidefinder\application\views\guide\tables.php 165
ERROR - 2018-05-16 09:24:55 --> Severity: Notice --> Undefined variable: name C:\wamp64\www\guidefinder\application\views\guide\tables.php 167
ERROR - 2018-05-16 09:24:55 --> Severity: Notice --> Undefined variable: email C:\wamp64\www\guidefinder\application\views\guide\tables.php 167
ERROR - 2018-05-16 09:24:55 --> Severity: Notice --> Undefined variable: phone C:\wamp64\www\guidefinder\application\views\guide\tables.php 167
ERROR - 2018-05-16 09:24:55 --> Severity: Notice --> Undefined variable: service_id C:\wamp64\www\guidefinder\application\views\guide\tables.php 167
ERROR - 2018-05-16 09:24:55 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:24:55 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:24:55 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:24:55 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:24:55 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:24:55 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 09:24:55 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 09:24:56 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:24:56 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:24:56 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:24:56 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:24:56 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:24:56 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 09:24:56 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 09:29:49 --> 404 Page Not Found: Guide/index.html
ERROR - 2018-05-16 09:29:54 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:29:54 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 09:29:54 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 09:29:54 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 09:29:58 --> 404 Page Not Found: Guide/index.html
ERROR - 2018-05-16 10:08:22 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:08:22 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:08:22 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 10:08:23 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:08:23 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:08:23 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:08:23 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 10:08:23 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:08:23 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:08:23 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:08:23 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:08:23 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:08:23 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 10:08:24 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 10:08:28 --> 404 Page Not Found: Guide/index.html
ERROR - 2018-05-16 10:08:31 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:08:31 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 10:08:31 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:08:31 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 10:17:48 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:17:48 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:17:48 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:17:48 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:17:48 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:17:48 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:17:48 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:17:48 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:17:48 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:17:48 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:18:17 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 234
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:22:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\guidefinder\application\views\guide\index.php 238
ERROR - 2018-05-16 10:29:00 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:29:00 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 10:29:00 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:29:00 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:29:00 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:29:00 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 10:29:00 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:29:01 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:29:01 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:29:01 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:29:01 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:29:01 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 10:29:01 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 10:29:01 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 10:40:39 --> 404 Page Not Found: Guide/index.php
ERROR - 2018-05-16 10:40:55 --> 404 Page Not Found: Guide/index.php
DEBUG - 2018-05-16 10:42:46 --> No URI present. Default controller set.
ERROR - 2018-05-16 10:47:20 --> 404 Page Not Found: Services/insert_data_guide
DEBUG - 2018-05-16 11:33:01 --> No URI present. Default controller set.
ERROR - 2018-05-16 12:05:33 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 12:05:33 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 12:05:33 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 12:05:33 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 12:05:34 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 12:05:34 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 12:05:34 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 12:05:34 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 12:05:34 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 12:05:34 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 12:05:34 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 12:05:34 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 12:05:34 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 12:05:34 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 12:05:35 --> 404 Page Not Found: Guide/index.html
ERROR - 2018-05-16 12:05:38 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 12:05:38 --> 404 Page Not Found: Guide/js
ERROR - 2018-05-16 12:05:38 --> 404 Page Not Found: Guide/vendor
ERROR - 2018-05-16 12:05:39 --> 404 Page Not Found: Guide/charts.html
DEBUG - 2018-05-16 17:41:23 --> No URI present. Default controller set.
DEBUG - 2018-05-16 18:14:35 --> No URI present. Default controller set.
ERROR - 2018-05-16 18:14:35 --> Query error: No database selected - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = 'fb7d8240b71d3f1b7372fd8925e15c442b602b70'
DEBUG - 2018-05-16 18:15:36 --> No URI present. Default controller set.
ERROR - 2018-05-16 18:15:36 --> Query error: No database selected - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = 'fb7d8240b71d3f1b7372fd8925e15c442b602b70'
DEBUG - 2018-05-16 18:17:04 --> No URI present. Default controller set.
