<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-16 05:41:17 --> No URI present. Default controller set.
ERROR - 2018-03-16 05:49:17 --> 404 Page Not Found: Webeasystep-codeigniter-nearest-markers-map-7b9369e14c71/index
DEBUG - 2018-03-16 05:49:18 --> No URI present. Default controller set.
ERROR - 2018-03-16 05:49:50 --> 404 Page Not Found: Webeasystep-codeigniter-nearest-markers-map-7b9369e14c71/index
DEBUG - 2018-03-16 05:49:58 --> No URI present. Default controller set.
DEBUG - 2018-03-16 05:50:00 --> No URI present. Default controller set.
DEBUG - 2018-03-16 05:50:31 --> No URI present. Default controller set.
DEBUG - 2018-03-16 05:50:53 --> No URI present. Default controller set.
DEBUG - 2018-03-16 05:51:36 --> No URI present. Default controller set.
DEBUG - 2018-03-16 05:51:48 --> No URI present. Default controller set.
DEBUG - 2018-03-16 05:52:34 --> No URI present. Default controller set.
ERROR - 2018-03-16 05:54:01 --> 404 Page Not Found: 1/index
DEBUG - 2018-03-16 05:54:05 --> No URI present. Default controller set.
DEBUG - 2018-03-16 05:54:11 --> No URI present. Default controller set.
DEBUG - 2018-03-16 05:54:25 --> No URI present. Default controller set.
ERROR - 2018-03-16 05:56:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'all--
    HAVING distance <= 30
    ORDER BY distance ASC' at line 9 - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://maps.google.com/mapfiles/ms/icons/green.png' AS icon,
    ( 6371 * acos( cos( radians(26.889941099999998) ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians(75.765986) ) + sin( radians(26.889941099999998) ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = --all--
    HAVING distance <= 30
    ORDER BY distance ASC
      
DEBUG - 2018-03-16 05:56:40 --> No URI present. Default controller set.
DEBUG - 2018-03-16 06:04:21 --> No URI present. Default controller set.
DEBUG - 2018-03-16 06:06:01 --> No URI present. Default controller set.
DEBUG - 2018-03-16 06:06:11 --> No URI present. Default controller set.
DEBUG - 2018-03-16 06:09:34 --> No URI present. Default controller set.
DEBUG - 2018-03-16 06:09:52 --> No URI present. Default controller set.
DEBUG - 2018-03-16 06:11:04 --> No URI present. Default controller set.
DEBUG - 2018-03-16 06:14:44 --> No URI present. Default controller set.
DEBUG - 2018-03-16 06:14:57 --> No URI present. Default controller set.
DEBUG - 2018-03-16 06:20:49 --> No URI present. Default controller set.
ERROR - 2018-03-16 06:21:14 --> 404 Page Not Found: Admin/index
ERROR - 2018-03-16 06:21:48 --> 404 Page Not Found: Services/admin
ERROR - 2018-03-16 06:22:15 --> Severity: Notice --> Undefined property: CI_Loader::$option C:\wamp64\www\webeasystep-codeigniter-nearest-markers-map-7b9369e14c71\application\views\admin\login.php 4
ERROR - 2018-03-16 06:23:06 --> Severity: Notice --> Undefined property: CI_Loader::$option C:\wamp64\www\webeasystep-codeigniter-nearest-markers-map-7b9369e14c71\application\views\admin\login.php 4
ERROR - 2018-03-16 06:23:15 --> Severity: Notice --> Undefined property: CI_Loader::$option C:\wamp64\www\webeasystep-codeigniter-nearest-markers-map-7b9369e14c71\application\views\admin\login.php 4
ERROR - 2018-03-16 06:23:25 --> Severity: Notice --> Undefined property: CI_Loader::$option C:\wamp64\www\webeasystep-codeigniter-nearest-markers-map-7b9369e14c71\application\views\admin\login.php 4
ERROR - 2018-03-16 06:24:32 --> Severity: Notice --> Undefined property: CI_Loader::$option C:\wamp64\www\webeasystep-codeigniter-nearest-markers-map-7b9369e14c71\application\views\admin\login.php 4
ERROR - 2018-03-16 06:25:39 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:26:01 --> 404 Page Not Found: Services/signup
ERROR - 2018-03-16 06:29:43 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:30:46 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:31:53 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:32:54 --> 404 Page Not Found: Services/signup.html
ERROR - 2018-03-16 06:33:22 --> 404 Page Not Found: Services/signup.html
ERROR - 2018-03-16 06:34:27 --> 404 Page Not Found: Services/signup.html
ERROR - 2018-03-16 06:34:45 --> 404 Page Not Found: Services/signup.html
ERROR - 2018-03-16 06:34:53 --> 404 Page Not Found: Services/signu.html
ERROR - 2018-03-16 06:39:12 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:40:40 --> 404 Page Not Found: Services/reset
ERROR - 2018-03-16 06:40:56 --> 404 Page Not Found: Services/reset
ERROR - 2018-03-16 06:41:06 --> 404 Page Not Found: Services/reset
ERROR - 2018-03-16 06:41:13 --> 404 Page Not Found: Services/trialbootnew
ERROR - 2018-03-16 06:41:45 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:41:47 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:41:50 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:41:51 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:41:52 --> 404 Page Not Found: Services/reset
ERROR - 2018-03-16 06:42:22 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:42:25 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:42:52 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:43:01 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:44:41 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:46:10 --> 404 Page Not Found: Services/reset
ERROR - 2018-03-16 06:48:06 --> 404 Page Not Found: Services/reset
ERROR - 2018-03-16 06:48:09 --> 404 Page Not Found: Services/reset
ERROR - 2018-03-16 06:49:10 --> 404 Page Not Found: Services/reset
ERROR - 2018-03-16 06:49:19 --> 404 Page Not Found: Services/reset
ERROR - 2018-03-16 06:50:02 --> 404 Page Not Found: Services/reset
ERROR - 2018-03-16 06:50:54 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:51:04 --> 404 Page Not Found: Services/trialbootnew
ERROR - 2018-03-16 06:51:26 --> 404 Page Not Found: Services/trialbootnew
ERROR - 2018-03-16 06:51:29 --> 404 Page Not Found: Services/signin
ERROR - 2018-03-16 06:51:46 --> 404 Page Not Found: Services/reset
ERROR - 2018-03-16 06:51:58 --> 404 Page Not Found: Services/reset
ERROR - 2018-03-16 06:52:23 --> 404 Page Not Found: Services/reset
ERROR - 2018-03-16 06:53:24 --> 404 Page Not Found: Services/reset
ERROR - 2018-03-16 06:53:32 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:53:48 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:53:51 --> 404 Page Not Found: Services/signin
ERROR - 2018-03-16 06:54:23 --> 404 Page Not Found: Services/white.jpg
ERROR - 2018-03-16 06:54:40 --> 404 Page Not Found: Services/signin
ERROR - 2018-03-16 06:54:47 --> 404 Page Not Found: Signin/index
ERROR - 2018-03-16 06:55:18 --> 404 Page Not Found: Signin/index
ERROR - 2018-03-16 06:56:52 --> 404 Page Not Found: Services/signin.php
DEBUG - 2018-03-16 06:58:09 --> No URI present. Default controller set.
ERROR - 2018-03-16 06:58:43 --> 404 Page Not Found: 1/index
DEBUG - 2018-03-16 06:58:49 --> No URI present. Default controller set.
DEBUG - 2018-03-16 06:58:59 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:00:29 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:00:59 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:04:29 --> No URI present. Default controller set.
ERROR - 2018-03-16 07:04:33 --> 404 Page Not Found: Sign/index
ERROR - 2018-03-16 07:05:08 --> 404 Page Not Found: Sign/index
DEBUG - 2018-03-16 07:05:09 --> No URI present. Default controller set.
ERROR - 2018-03-16 07:05:12 --> 404 Page Not Found: Login/index
DEBUG - 2018-03-16 07:05:24 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:08:15 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:08:15 --> No URI present. Default controller set.
ERROR - 2018-03-16 07:08:34 --> 404 Page Not Found: Services/Services
ERROR - 2018-03-16 07:08:49 --> 404 Page Not Found: Services/Services
ERROR - 2018-03-16 07:09:13 --> 404 Page Not Found: Services/Services
DEBUG - 2018-03-16 07:09:31 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:09:31 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:10:35 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:10:36 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:13:43 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:19:04 --> No URI present. Default controller set.
ERROR - 2018-03-16 07:19:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'all--
    HAVING distance <= 30
    ORDER BY distance ASC' at line 9 - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://maps.google.com/mapfiles/ms/icons/green.png' AS icon,
    ( 6371 * acos( cos( radians(26.8899375) ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians(75.765982) ) + sin( radians(26.8899375) ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = --all--
    HAVING distance <= 30
    ORDER BY distance ASC
      
ERROR - 2018-03-16 07:19:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'all--
    HAVING distance <= 30
    ORDER BY distance ASC' at line 9 - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://maps.google.com/mapfiles/ms/icons/green.png' AS icon,
    ( 6371 * acos( cos( radians(26.8899375) ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians(75.765982) ) + sin( radians(26.8899375) ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = --all--
    HAVING distance <= 30
    ORDER BY distance ASC
      
DEBUG - 2018-03-16 07:19:40 --> No URI present. Default controller set.
ERROR - 2018-03-16 07:19:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'all--
    HAVING distance <= 30
    ORDER BY distance ASC' at line 9 - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://maps.google.com/mapfiles/ms/icons/green.png' AS icon,
    ( 6371 * acos( cos( radians(26.8899375) ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians(75.765982) ) + sin( radians(26.8899375) ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = --all--
    HAVING distance <= 30
    ORDER BY distance ASC
      
ERROR - 2018-03-16 07:19:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'all--
    HAVING distance <= 30
    ORDER BY distance ASC' at line 9 - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://maps.google.com/mapfiles/ms/icons/green.png' AS icon,
    ( 6371 * acos( cos( radians(26.8899375) ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians(75.765982) ) + sin( radians(26.8899375) ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = --all--
    HAVING distance <= 30
    ORDER BY distance ASC
      
ERROR - 2018-03-16 07:19:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'all--
    HAVING distance <= 30
    ORDER BY distance ASC' at line 9 - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://maps.google.com/mapfiles/ms/icons/green.png' AS icon,
    ( 6371 * acos( cos( radians(26.8899375) ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians(75.765982) ) + sin( radians(26.8899375) ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = --all--
    HAVING distance <= 30
    ORDER BY distance ASC
      
ERROR - 2018-03-16 07:19:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'all--
    HAVING distance <= 30
    ORDER BY distance ASC' at line 9 - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://maps.google.com/mapfiles/ms/icons/green.png' AS icon,
    ( 6371 * acos( cos( radians(26.8899375) ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians(75.765982) ) + sin( radians(26.8899375) ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = --all--
    HAVING distance <= 30
    ORDER BY distance ASC
      
ERROR - 2018-03-16 07:19:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'all--
    HAVING distance <= 30
    ORDER BY distance ASC' at line 9 - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://maps.google.com/mapfiles/ms/icons/green.png' AS icon,
    ( 6371 * acos( cos( radians(26.8899375) ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians(75.765982) ) + sin( radians(26.8899375) ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = --all--
    HAVING distance <= 30
    ORDER BY distance ASC
      
ERROR - 2018-03-16 07:19:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'all--
    HAVING distance <= 30
    ORDER BY distance ASC' at line 9 - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://maps.google.com/mapfiles/ms/icons/green.png' AS icon,
    ( 6371 * acos( cos( radians(26.8899375) ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians(75.765982) ) + sin( radians(26.8899375) ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = --all--
    HAVING distance <= 30
    ORDER BY distance ASC
      
ERROR - 2018-03-16 07:19:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'all--
    HAVING distance <= 30
    ORDER BY distance ASC' at line 9 - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://maps.google.com/mapfiles/ms/icons/green.png' AS icon,
    ( 6371 * acos( cos( radians(26.8899375) ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians(75.765982) ) + sin( radians(26.8899375) ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = --all--
    HAVING distance <= 30
    ORDER BY distance ASC
      
DEBUG - 2018-03-16 07:43:28 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:43:53 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:44:13 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:44:42 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:44:47 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:44:57 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:45:12 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:45:22 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:45:43 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:45:43 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:45:48 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:46:16 --> No URI present. Default controller set.
ERROR - 2018-03-16 07:46:22 --> 404 Page Not Found: Services/Services
ERROR - 2018-03-16 07:46:52 --> 404 Page Not Found: Services/Services
ERROR - 2018-03-16 07:46:56 --> 404 Page Not Found: Services/Services
DEBUG - 2018-03-16 07:47:12 --> No URI present. Default controller set.
DEBUG - 2018-03-16 07:47:13 --> No URI present. Default controller set.
ERROR - 2018-03-16 07:47:17 --> 404 Page Not Found: Services/Services
DEBUG - 2018-03-16 09:10:46 --> No URI present. Default controller set.
ERROR - 2018-03-16 09:10:53 --> 404 Page Not Found: Services/Services
ERROR - 2018-03-16 09:11:12 --> 404 Page Not Found: Services/Services
ERROR - 2018-03-16 09:18:20 --> 404 Page Not Found: Services/Services
ERROR - 2018-03-16 09:19:43 --> 404 Page Not Found: Services/Services
ERROR - 2018-03-16 09:19:55 --> 404 Page Not Found: Services/Services
ERROR - 2018-03-16 09:20:08 --> 404 Page Not Found: Services/Services
ERROR - 2018-03-16 09:20:21 --> 404 Page Not Found: Services/Services
DEBUG - 2018-03-16 09:20:37 --> No URI present. Default controller set.
DEBUG - 2018-03-16 09:20:38 --> No URI present. Default controller set.
DEBUG - 2018-03-16 09:20:44 --> No URI present. Default controller set.
ERROR - 2018-03-16 09:20:49 --> 404 Page Not Found: Services/Services
DEBUG - 2018-03-16 09:27:44 --> No URI present. Default controller set.
ERROR - 2018-03-16 10:40:52 --> 404 Page Not Found: Login/index
DEBUG - 2018-03-16 10:40:55 --> No URI present. Default controller set.
ERROR - 2018-03-16 10:40:57 --> 404 Page Not Found: Signup/index
DEBUG - 2018-03-16 10:41:01 --> No URI present. Default controller set.
ERROR - 2018-03-16 10:41:04 --> 404 Page Not Found: Login/index
DEBUG - 2018-03-16 10:41:06 --> No URI present. Default controller set.
DEBUG - 2018-03-16 10:41:54 --> No URI present. Default controller set.
ERROR - 2018-03-16 10:42:01 --> 404 Page Not Found: Login/index
DEBUG - 2018-03-16 10:42:03 --> No URI present. Default controller set.
DEBUG - 2018-03-16 10:45:19 --> No URI present. Default controller set.
DEBUG - 2018-03-16 10:45:39 --> No URI present. Default controller set.
ERROR - 2018-03-16 10:45:45 --> 404 Page Not Found: Login/index
DEBUG - 2018-03-16 10:45:50 --> No URI present. Default controller set.
DEBUG - 2018-03-16 10:47:30 --> No URI present. Default controller set.
DEBUG - 2018-03-16 10:48:47 --> No URI present. Default controller set.
ERROR - 2018-03-16 10:48:51 --> 404 Page Not Found: Login/index
ERROR - 2018-03-16 10:49:02 --> 404 Page Not Found: Servicelogin/index
ERROR - 2018-03-16 10:49:06 --> 404 Page Not Found: Service/login
DEBUG - 2018-03-16 10:52:01 --> No URI present. Default controller set.
ERROR - 2018-03-16 10:52:04 --> 404 Page Not Found: Login/index
DEBUG - 2018-03-16 10:53:47 --> No URI present. Default controller set.
DEBUG - 2018-03-16 10:54:25 --> No URI present. Default controller set.
ERROR - 2018-03-16 11:02:27 --> Query error: Table 'demo.demo' doesn't exist - Invalid query: INSERT INTO `demo` (`name`, `email`, `phone`, `address`, `password`, `username`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2018-03-16 11:03:20 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `users` (`name`, `email`, `phone`, `address`, `password`, `username`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2018-03-16 11:04:02 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `users` (`name`, `email`, `phone`, `address`, `password`, `username`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL)
DEBUG - 2018-03-16 11:29:36 --> No URI present. Default controller set.
DEBUG - 2018-03-16 11:30:01 --> No URI present. Default controller set.
DEBUG - 2018-03-16 11:30:42 --> No URI present. Default controller set.
ERROR - 2018-03-16 11:31:32 --> Severity: Notice --> Undefined variable: password C:\wamp64\www\guidefinder\application\controllers\Services.php 120
ERROR - 2018-03-16 11:32:43 --> 404 Page Not Found: Service/index
DEBUG - 2018-03-16 11:34:23 --> No URI present. Default controller set.
DEBUG - 2018-03-16 11:34:24 --> No URI present. Default controller set.
DEBUG - 2018-03-16 11:34:51 --> No URI present. Default controller set.
DEBUG - 2018-03-16 11:37:40 --> No URI present. Default controller set.
DEBUG - 2018-03-16 11:45:31 --> No URI present. Default controller set.
ERROR - 2018-03-16 11:48:44 --> 404 Page Not Found: 2/index
ERROR - 2018-03-16 11:49:04 --> 404 Page Not Found: 2/index
ERROR - 2018-03-16 11:49:39 --> 404 Page Not Found: 2/index
DEBUG - 2018-03-16 11:50:00 --> No URI present. Default controller set.
ERROR - 2018-03-16 11:51:39 --> 404 Page Not Found: 3/index
ERROR - 2018-03-16 11:56:38 --> 404 Page Not Found: 3/index
ERROR - 2018-03-16 12:01:00 --> 404 Page Not Found: 3/index
DEBUG - 2018-03-16 12:02:13 --> No URI present. Default controller set.
DEBUG - 2018-03-16 12:02:14 --> No URI present. Default controller set.
DEBUG - 2018-03-16 15:24:21 --> No URI present. Default controller set.
DEBUG - 2018-03-16 15:24:21 --> No URI present. Default controller set.
ERROR - 2018-03-16 15:25:27 --> Query error: Incorrect parameter count in the call to native function 'radians' - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://maps.google.com/mapfiles/ms/icons/green.png' AS icon,
    ( 6371 * acos( cos( radians() ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians() ) + sin( radians() ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = 1
    HAVING distance <= 10
    ORDER BY distance ASC
      
ERROR - 2018-03-16 15:25:33 --> Query error: Incorrect parameter count in the call to native function 'radians' - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://maps.google.com/mapfiles/ms/icons/green.png' AS icon,
    ( 6371 * acos( cos( radians() ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians() ) + sin( radians() ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = 1
    HAVING distance <= 10
    ORDER BY distance ASC
      
DEBUG - 2018-03-16 15:47:12 --> No URI present. Default controller set.
DEBUG - 2018-03-16 16:14:09 --> No URI present. Default controller set.
DEBUG - 2018-03-16 16:28:48 --> No URI present. Default controller set.
ERROR - 2018-03-16 16:49:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'all--
    HAVING distance <= 10
    ORDER BY distance ASC' at line 9 - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://maps.google.com/mapfiles/ms/icons/green.png' AS icon,
    ( 6371 * acos( cos( radians(26.869490499999998) ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians(75.8042406) ) + sin( radians(26.869490499999998) ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = --all--
    HAVING distance <= 10
    ORDER BY distance ASC
      
DEBUG - 2018-03-16 16:57:56 --> No URI present. Default controller set.
DEBUG - 2018-03-16 16:58:04 --> No URI present. Default controller set.
DEBUG - 2018-03-16 17:27:43 --> No URI present. Default controller set.
DEBUG - 2018-03-16 17:27:54 --> No URI present. Default controller set.
DEBUG - 2018-03-16 17:28:48 --> No URI present. Default controller set.
ERROR - 2018-03-16 17:36:14 --> 404 Page Not Found: Admin/package-1
ERROR - 2018-03-16 17:38:13 --> 404 Page Not Found: Admin/package-1
ERROR - 2018-03-16 17:38:30 --> 404 Page Not Found: Admin/services
ERROR - 2018-03-16 17:41:15 --> 404 Page Not Found: Admin/package-1
ERROR - 2018-03-16 17:41:32 --> 404 Page Not Found: Services/package-1
ERROR - 2018-03-16 17:43:43 --> 404 Page Not Found: Services/package-1
ERROR - 2018-03-16 17:44:14 --> 404 Page Not Found: Services/package-1.php
ERROR - 2018-03-16 17:55:03 --> 404 Page Not Found: Services/package-1
DEBUG - 2018-03-16 18:29:29 --> No URI present. Default controller set.
DEBUG - 2018-03-16 18:29:37 --> No URI present. Default controller set.
DEBUG - 2018-03-16 18:29:45 --> No URI present. Default controller set.
DEBUG - 2018-03-16 18:29:55 --> No URI present. Default controller set.
DEBUG - 2018-03-16 18:32:56 --> No URI present. Default controller set.
DEBUG - 2018-03-16 18:33:09 --> No URI present. Default controller set.
DEBUG - 2018-03-16 18:33:19 --> No URI present. Default controller set.
