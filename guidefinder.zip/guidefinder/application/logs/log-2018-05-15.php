<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-15 15:29:08 --> 404 Page Not Found: Images/raj.jpg
ERROR - 2018-05-15 15:29:09 --> 404 Page Not Found: Images/namaskar.png
ERROR - 2018-05-15 15:29:20 --> 404 Page Not Found: Images/raj.jpg
ERROR - 2018-05-15 15:29:20 --> 404 Page Not Found: Images/namaskar.png
ERROR - 2018-05-15 15:30:33 --> 404 Page Not Found: Images/raj.jpg
ERROR - 2018-05-15 15:30:33 --> 404 Page Not Found: Images/namaskar.png
ERROR - 2018-05-15 15:30:33 --> 404 Page Not Found: Images/signin.png
DEBUG - 2018-05-15 15:33:24 --> No URI present. Default controller set.
DEBUG - 2018-05-15 15:34:34 --> No URI present. Default controller set.
DEBUG - 2018-05-15 15:34:41 --> No URI present. Default controller set.
DEBUG - 2018-05-15 15:34:45 --> No URI present. Default controller set.
DEBUG - 2018-05-15 15:40:02 --> No URI present. Default controller set.
DEBUG - 2018-05-15 15:41:13 --> No URI present. Default controller set.
DEBUG - 2018-05-15 15:42:05 --> No URI present. Default controller set.
DEBUG - 2018-05-15 15:42:25 --> No URI present. Default controller set.
DEBUG - 2018-05-15 15:42:29 --> No URI present. Default controller set.
DEBUG - 2018-05-15 15:42:32 --> No URI present. Default controller set.
DEBUG - 2018-05-15 15:44:46 --> No URI present. Default controller set.
DEBUG - 2018-05-15 15:45:07 --> No URI present. Default controller set.
DEBUG - 2018-05-15 15:56:28 --> No URI present. Default controller set.
DEBUG - 2018-05-15 16:13:00 --> No URI present. Default controller set.
DEBUG - 2018-05-15 16:13:01 --> No URI present. Default controller set.
DEBUG - 2018-05-15 16:13:22 --> No URI present. Default controller set.
DEBUG - 2018-05-15 16:13:35 --> No URI present. Default controller set.
DEBUG - 2018-05-15 16:14:41 --> No URI present. Default controller set.
DEBUG - 2018-05-15 16:15:56 --> No URI present. Default controller set.
DEBUG - 2018-05-15 16:15:56 --> No URI present. Default controller set.
DEBUG - 2018-05-15 16:16:01 --> No URI present. Default controller set.
ERROR - 2018-05-15 16:20:18 --> 404 Page Not Found: Services/images
ERROR - 2018-05-15 16:20:18 --> 404 Page Not Found: Services/images
DEBUG - 2018-05-15 16:23:28 --> No URI present. Default controller set.
ERROR - 2018-05-15 16:24:15 --> 404 Page Not Found: Services/images
ERROR - 2018-05-15 16:24:15 --> 404 Page Not Found: Services/images
DEBUG - 2018-05-15 16:26:20 --> No URI present. Default controller set.
ERROR - 2018-05-15 16:26:20 --> 404 Page Not Found: Images/raj.jpg
DEBUG - 2018-05-15 16:26:23 --> No URI present. Default controller set.
ERROR - 2018-05-15 16:26:25 --> 404 Page Not Found: Images/raj.jpg
DEBUG - 2018-05-15 16:26:45 --> No URI present. Default controller set.
ERROR - 2018-05-15 16:26:47 --> 404 Page Not Found: Images/raj.jpg
DEBUG - 2018-05-15 16:27:37 --> No URI present. Default controller set.
DEBUG - 2018-05-15 16:29:39 --> No URI present. Default controller set.
DEBUG - 2018-05-15 16:30:20 --> No URI present. Default controller set.
DEBUG - 2018-05-15 16:38:35 --> No URI present. Default controller set.
ERROR - 2018-05-15 16:38:53 --> 404 Page Not Found: Services/images
ERROR - 2018-05-15 16:38:53 --> 404 Page Not Found: Services/images
