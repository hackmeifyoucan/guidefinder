<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-07-09 08:27:14 --> No URI present. Default controller set.
