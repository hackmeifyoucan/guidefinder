<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-04-12 17:57:36 --> No URI present. Default controller set.
