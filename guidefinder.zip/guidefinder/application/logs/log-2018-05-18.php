<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-05-18 08:51:49 --> No URI present. Default controller set.
DEBUG - 2018-05-18 09:24:44 --> No URI present. Default controller set.
