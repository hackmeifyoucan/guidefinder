<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-21 00:14:42 --> No URI present. Default controller set.
DEBUG - 2018-03-21 00:18:15 --> No URI present. Default controller set.
DEBUG - 2018-03-21 00:31:54 --> No URI present. Default controller set.
DEBUG - 2018-03-21 00:33:26 --> No URI present. Default controller set.
DEBUG - 2018-03-21 00:33:34 --> No URI present. Default controller set.
DEBUG - 2018-03-21 00:33:54 --> No URI present. Default controller set.
DEBUG - 2018-03-21 00:39:02 --> No URI present. Default controller set.
DEBUG - 2018-03-21 00:43:28 --> No URI present. Default controller set.
DEBUG - 2018-03-21 01:27:14 --> No URI present. Default controller set.
