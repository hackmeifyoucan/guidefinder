<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-17 05:12:02 --> No URI present. Default controller set.
ERROR - 2018-03-17 05:12:57 --> 404 Page Not Found: Services/package-1
ERROR - 2018-03-17 05:24:40 --> 404 Page Not Found: Services/logout.php
ERROR - 2018-03-17 05:25:09 --> 404 Page Not Found: Services/logout.php
ERROR - 2018-03-17 05:25:20 --> 404 Page Not Found: Services/package-1
ERROR - 2018-03-17 05:26:53 --> 404 Page Not Found: Services/logout.php
ERROR - 2018-03-17 05:27:48 --> 404 Page Not Found: Services/login
ERROR - 2018-03-17 05:28:18 --> 404 Page Not Found: Services/login
ERROR - 2018-03-17 05:30:55 --> 404 Page Not Found: Services/login
ERROR - 2018-03-17 05:32:22 --> 404 Page Not Found: Services/login
ERROR - 2018-03-17 05:35:39 --> 404 Page Not Found: Services/login
DEBUG - 2018-03-17 05:36:04 --> No URI present. Default controller set.
ERROR - 2018-03-17 05:36:16 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\wamp64\www\guidefindernew\application\controllers\Services.php 127
ERROR - 2018-03-17 05:36:25 --> 404 Page Not Found: Services/login
DEBUG - 2018-03-17 05:37:26 --> No URI present. Default controller set.
ERROR - 2018-03-17 05:37:47 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\wamp64\www\guidefindernew\application\controllers\Services.php 127
DEBUG - 2018-03-17 06:12:32 --> No URI present. Default controller set.
ERROR - 2018-03-17 06:16:27 --> 404 Page Not Found: Close_session/index
DEBUG - 2018-03-17 06:16:34 --> No URI present. Default controller set.
DEBUG - 2018-03-17 06:16:43 --> No URI present. Default controller set.
DEBUG - 2018-03-17 06:44:52 --> No URI present. Default controller set.
DEBUG - 2018-03-17 06:45:49 --> No URI present. Default controller set.
DEBUG - 2018-03-17 06:46:52 --> No URI present. Default controller set.
ERROR - 2018-03-17 06:47:06 --> 404 Page Not Found: Close_session/index
ERROR - 2018-03-17 06:47:49 --> 404 Page Not Found: Service/close_session
DEBUG - 2018-03-17 06:51:53 --> No URI present. Default controller set.
ERROR - 2018-03-17 06:53:34 --> 404 Page Not Found: 3/index
ERROR - 2018-03-17 07:26:12 --> 404 Page Not Found: 1/index
ERROR - 2018-03-17 07:38:32 --> 404 Page Not Found: Services/request_guide.1
ERROR - 2018-03-17 07:38:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `email` = 'faisalahmed.vgu@gmail.com'' at line 2 - Invalid query: SELECT *
WHERE `email` = 'faisalahmed.vgu@gmail.com'
ERROR - 2018-03-17 07:50:50 --> Severity: Notice --> Undefined property: stdClass::$number C:\wamp64\www\guidefindernew\application\controllers\Services.php 161
DEBUG - 2018-03-17 07:52:27 --> No URI present. Default controller set.
DEBUG - 2018-03-17 07:53:09 --> No URI present. Default controller set.
DEBUG - 2018-03-17 07:53:43 --> No URI present. Default controller set.
DEBUG - 2018-03-17 07:53:46 --> No URI present. Default controller set.
DEBUG - 2018-03-17 07:57:00 --> No URI present. Default controller set.
ERROR - 2018-03-17 07:57:23 --> Severity: Notice --> Undefined property: stdClass::$number C:\wamp64\www\guidefindernew\application\controllers\Services.php 161
ERROR - 2018-03-17 07:57:23 --> Query error: Table 'demo.request' doesn't exist - Invalid query: INSERT INTO `request` (`name`, `email`, `phone`, `receiver_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', NULL, '1')
ERROR - 2018-03-17 07:57:49 --> Severity: Notice --> Undefined property: stdClass::$number C:\wamp64\www\guidefindernew\application\controllers\Services.php 161
ERROR - 2018-03-17 07:57:49 --> Query error: Unknown column 'receiver_id' in 'field list' - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `receiver_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', NULL, '1')
ERROR - 2018-03-17 08:07:32 --> Severity: Notice --> Undefined property: stdClass::$number C:\wamp64\www\guidefindernew\application\controllers\Services.php 161
ERROR - 2018-03-17 08:07:32 --> Query error: Unknown column 'receiver_id' in 'field list' - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `receiver_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', NULL, '1')
ERROR - 2018-03-17 08:07:47 --> Severity: Notice --> Undefined property: stdClass::$number C:\wamp64\www\guidefindernew\application\controllers\Services.php 161
ERROR - 2018-03-17 08:07:47 --> Query error: Unknown column 'receiver_id' in 'field list' - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `receiver_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', NULL, '1')
ERROR - 2018-03-17 08:08:24 --> Severity: Notice --> Undefined property: stdClass::$number C:\wamp64\www\guidefindernew\application\controllers\Services.php 161
ERROR - 2018-03-17 08:08:24 --> Query error: Unknown column 'receiver_id' in 'field list' - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `receiver_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', NULL, '1')
ERROR - 2018-03-17 08:08:45 --> Severity: Notice --> Undefined property: stdClass::$number C:\wamp64\www\guidefindernew\application\controllers\Services.php 161
ERROR - 2018-03-17 08:08:45 --> Query error: Unknown column 'receiver_id' in 'field list' - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `receiver_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', NULL, '1')
ERROR - 2018-03-17 08:09:02 --> Severity: Notice --> Undefined property: stdClass::$number C:\wamp64\www\guidefindernew\application\controllers\Services.php 161
ERROR - 2018-03-17 08:09:02 --> Query error: Unknown column 'receiver_id' in 'field list' - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `receiver_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', NULL, '1')
ERROR - 2018-03-17 08:09:11 --> Severity: Notice --> Undefined property: stdClass::$number C:\wamp64\www\guidefindernew\application\controllers\Services.php 161
ERROR - 2018-03-17 08:09:11 --> Query error: Unknown column 'receiver_id' in 'field list' - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `receiver_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', NULL, '1')
ERROR - 2018-03-17 08:09:51 --> Severity: Notice --> Undefined property: stdClass::$number C:\wamp64\www\guidefindernew\application\controllers\Services.php 161
ERROR - 2018-03-17 08:09:51 --> Query error: Unknown column 'receiver_id' in 'field list' - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `receiver_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', NULL, '1')
ERROR - 2018-03-17 08:11:32 --> Severity: Notice --> Undefined property: stdClass::$number C:\wamp64\www\guidefindernew\application\controllers\Services.php 161
ERROR - 2018-03-17 08:11:32 --> Query error: Unknown column 'receiver_id' in 'field list' - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `receiver_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', NULL, '1')
ERROR - 2018-03-17 08:11:34 --> Severity: Notice --> Undefined property: stdClass::$number C:\wamp64\www\guidefindernew\application\controllers\Services.php 161
ERROR - 2018-03-17 08:11:34 --> Query error: Unknown column 'receiver_id' in 'field list' - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `receiver_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', NULL, '1')
ERROR - 2018-03-17 08:13:35 --> Query error: Unknown column 'receiver_id' in 'field list' - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `receiver_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', '2147483647', '1')
ERROR - 2018-03-17 08:43:04 --> 404 Page Not Found: Services/package-1
ERROR - 2018-03-17 08:43:31 --> 404 Page Not Found: Services/admin
ERROR - 2018-03-17 08:44:12 --> 404 Page Not Found: Services/views
ERROR - 2018-03-17 08:44:42 --> 404 Page Not Found: Services/views
DEBUG - 2018-03-17 08:58:25 --> No URI present. Default controller set.
DEBUG - 2018-03-17 08:58:25 --> No URI present. Default controller set.
DEBUG - 2018-03-17 08:58:36 --> No URI present. Default controller set.
DEBUG - 2018-03-17 09:06:17 --> No URI present. Default controller set.
DEBUG - 2018-03-17 09:08:38 --> No URI present. Default controller set.
DEBUG - 2018-03-17 18:18:35 --> No URI present. Default controller set.
