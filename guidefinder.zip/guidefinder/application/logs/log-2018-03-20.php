<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-20 02:29:00 --> No URI present. Default controller set.
DEBUG - 2018-03-20 02:29:01 --> No URI present. Default controller set.
ERROR - 2018-03-20 02:38:18 --> 404 Page Not Found: Services/index.php
ERROR - 2018-03-20 02:38:46 --> 404 Page Not Found: Services/index.php
ERROR - 2018-03-20 02:38:54 --> 404 Page Not Found: Services/index.php
ERROR - 2018-03-20 02:40:41 --> 404 Page Not Found: Services/services
ERROR - 2018-03-20 02:41:08 --> 404 Page Not Found: Services/services
ERROR - 2018-03-20 02:41:25 --> 404 Page Not Found: Services/services
DEBUG - 2018-03-20 02:49:52 --> No URI present. Default controller set.
DEBUG - 2018-03-20 02:54:27 --> No URI present. Default controller set.
DEBUG - 2018-03-20 02:54:28 --> No URI present. Default controller set.
DEBUG - 2018-03-20 02:55:14 --> No URI present. Default controller set.
ERROR - 2018-03-20 02:55:32 --> Severity: Notice --> Undefined variable: session_data_guide C:\wamp64\www\guidefindernew\application\controllers\Services.php 191
ERROR - 2018-03-20 02:55:32 --> 404 Page Not Found: Views/guide
ERROR - 2018-03-20 02:56:31 --> 404 Page Not Found: Views/guide
ERROR - 2018-03-20 03:08:42 --> 404 Page Not Found: Services/guide
DEBUG - 2018-03-20 03:12:44 --> No URI present. Default controller set.
DEBUG - 2018-03-20 03:12:45 --> No URI present. Default controller set.
ERROR - 2018-03-20 03:21:50 --> 404 Page Not Found: Admin/packages
ERROR - 2018-03-20 03:21:56 --> 404 Page Not Found: Admin/packages
ERROR - 2018-03-20 03:22:14 --> 404 Page Not Found: Admin/packagestourist
ERROR - 2018-03-20 03:23:42 --> 404 Page Not Found: Admin/packages
ERROR - 2018-03-20 03:24:04 --> 404 Page Not Found: Services/raj1.jpg
ERROR - 2018-03-20 03:26:51 --> 404 Page Not Found: Services/raj1.jpg
ERROR - 2018-03-20 03:41:13 --> 404 Page Not Found: Services/raj1.jpg
ERROR - 2018-03-20 03:41:20 --> 404 Page Not Found: Services/raj1.jpg
DEBUG - 2018-03-20 03:41:40 --> No URI present. Default controller set.
DEBUG - 2018-03-20 03:54:38 --> No URI present. Default controller set.
DEBUG - 2018-03-20 03:54:38 --> No URI present. Default controller set.
DEBUG - 2018-03-20 03:54:55 --> No URI present. Default controller set.
DEBUG - 2018-03-20 03:57:48 --> No URI present. Default controller set.
ERROR - 2018-03-20 04:27:30 --> 404 Page Not Found: Services/raj1.jpg
ERROR - 2018-03-20 05:04:04 --> 404 Page Not Found: Services/raj1.jpg
DEBUG - 2018-03-20 05:08:19 --> No URI present. Default controller set.
DEBUG - 2018-03-20 05:08:23 --> No URI present. Default controller set.
DEBUG - 2018-03-20 05:09:48 --> No URI present. Default controller set.
DEBUG - 2018-03-20 05:10:24 --> No URI present. Default controller set.
DEBUG - 2018-03-20 05:11:14 --> No URI present. Default controller set.
ERROR - 2018-03-20 05:12:26 --> 404 Page Not Found: Services/raj1.jpg
ERROR - 2018-03-20 05:14:57 --> 404 Page Not Found: Services/raj1.jpg
ERROR - 2018-03-20 05:15:30 --> 404 Page Not Found: Services/raj1.jpg
ERROR - 2018-03-20 05:22:25 --> 404 Page Not Found: Services/raj1.jpg
DEBUG - 2018-03-20 05:22:43 --> No URI present. Default controller set.
DEBUG - 2018-03-20 05:22:52 --> No URI present. Default controller set.
ERROR - 2018-03-20 05:23:10 --> 404 Page Not Found: Services/raj1.jpg
ERROR - 2018-03-20 05:24:23 --> 404 Page Not Found: Services/raj1.jpg
ERROR - 2018-03-20 05:25:27 --> 404 Page Not Found: Services/raj1.jpg
ERROR - 2018-03-20 05:30:08 --> 404 Page Not Found: Services/raj1.jpg
DEBUG - 2018-03-20 05:37:29 --> No URI present. Default controller set.
DEBUG - 2018-03-20 05:37:30 --> No URI present. Default controller set.
DEBUG - 2018-03-20 05:38:28 --> No URI present. Default controller set.
ERROR - 2018-03-20 05:38:31 --> 404 Page Not Found: Service/login
DEBUG - 2018-03-20 05:38:34 --> No URI present. Default controller set.
DEBUG - 2018-03-20 05:40:29 --> No URI present. Default controller set.
DEBUG - 2018-03-20 05:42:16 --> No URI present. Default controller set.
DEBUG - 2018-03-20 05:42:19 --> No URI present. Default controller set.
DEBUG - 2018-03-20 05:43:24 --> No URI present. Default controller set.
DEBUG - 2018-03-20 05:43:36 --> No URI present. Default controller set.
DEBUG - 2018-03-20 05:44:02 --> No URI present. Default controller set.
ERROR - 2018-03-20 05:44:45 --> 404 Page Not Found: Services/raj.jpg
ERROR - 2018-03-20 05:44:45 --> 404 Page Not Found: Services/namaskar.png
ERROR - 2018-03-20 05:44:45 --> 404 Page Not Found: Services/signin.png
ERROR - 2018-03-20 05:44:45 --> 404 Page Not Found: Services/hand.png
ERROR - 2018-03-20 05:44:45 --> 404 Page Not Found: Services/explore.png
ERROR - 2018-03-20 05:47:24 --> 404 Page Not Found: Services/hand.png
ERROR - 2018-03-20 05:47:24 --> 404 Page Not Found: Services/explore.png
ERROR - 2018-03-20 05:49:38 --> 404 Page Not Found: Services/admin
ERROR - 2018-03-20 05:52:44 --> 404 Page Not Found: Services/admin
DEBUG - 2018-03-20 07:17:57 --> No URI present. Default controller set.
DEBUG - 2018-03-20 07:19:02 --> No URI present. Default controller set.
DEBUG - 2018-03-20 07:19:28 --> No URI present. Default controller set.
DEBUG - 2018-03-20 07:23:19 --> No URI present. Default controller set.
DEBUG - 2018-03-20 07:23:33 --> No URI present. Default controller set.
DEBUG - 2018-03-20 07:23:52 --> No URI present. Default controller set.
DEBUG - 2018-03-20 07:24:43 --> No URI present. Default controller set.
DEBUG - 2018-03-20 07:24:48 --> No URI present. Default controller set.
DEBUG - 2018-03-20 07:25:03 --> No URI present. Default controller set.
DEBUG - 2018-03-20 07:28:23 --> No URI present. Default controller set.
DEBUG - 2018-03-20 07:29:05 --> No URI present. Default controller set.
DEBUG - 2018-03-20 07:30:46 --> No URI present. Default controller set.
DEBUG - 2018-03-20 07:31:00 --> No URI present. Default controller set.
DEBUG - 2018-03-20 07:31:38 --> No URI present. Default controller set.
DEBUG - 2018-03-20 07:32:00 --> No URI present. Default controller set.
DEBUG - 2018-03-20 09:26:23 --> No URI present. Default controller set.
ERROR - 2018-03-20 10:27:48 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('faisalahmed', 'faisalahmed.vgu@gmail.com', NULL, '3635', '1542', NULL)
ERROR - 2018-03-20 10:29:54 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('faisalahmed', 'faisalahmed.vgu@gmail.com', NULL, '2355.5', '42655.5', NULL)
ERROR - 2018-03-20 10:39:51 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('faisalahmed', 'faisalahmed.vgu@gmail.com', NULL, '2355.5', '42655.5', NULL)
ERROR - 2018-03-20 10:40:09 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('faisalahmed', 'faisalahmed.vgu@gmail.com', NULL, '2355.5', '42655.5', NULL)
ERROR - 2018-03-20 10:40:39 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('faisalahmed', 'faisalahmed.vgu@gmail.com', NULL, '2355.5', '42655.5', NULL)
ERROR - 2018-03-20 10:41:19 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('faisalahmed', 'faisalahmed.vgu@gmail.com', NULL, '2355.5', '42655.5', NULL)
ERROR - 2018-03-20 10:42:09 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('faisalahmed', 'faisalahmed.vgu@gmail.com', NULL, '626161', '61616', NULL)
ERROR - 2018-03-20 11:30:28 --> Severity: Notice --> Array to string conversion C:\wamp64\www\guidefindernew\application\controllers\Services.php 210
ERROR - 2018-03-20 11:31:55 --> Severity: Notice --> Array to string conversion C:\wamp64\www\guidefindernew\application\controllers\Services.php 210
ERROR - 2018-03-20 11:32:08 --> Severity: Notice --> Array to string conversion C:\wamp64\www\guidefindernew\application\controllers\Services.php 210
ERROR - 2018-03-20 11:32:40 --> Severity: Notice --> Array to string conversion C:\wamp64\www\guidefindernew\application\controllers\Services.php 210
ERROR - 2018-03-20 11:33:54 --> Severity: Notice --> Array to string conversion C:\wamp64\www\guidefindernew\application\controllers\Services.php 210
ERROR - 2018-03-20 11:34:47 --> Severity: Notice --> Array to string conversion C:\wamp64\www\guidefindernew\application\controllers\Services.php 210
ERROR - 2018-03-20 11:40:47 --> Severity: Notice --> Array to string conversion C:\wamp64\www\guidefindernew\application\controllers\Services.php 210
ERROR - 2018-03-20 11:42:40 --> Severity: Notice --> Array to string conversion C:\wamp64\www\guidefindernew\application\controllers\Services.php 210
ERROR - 2018-03-20 12:03:40 --> 404 Page Not Found: Views/guide
ERROR - 2018-03-20 12:08:40 --> 404 Page Not Found: Views/guide
DEBUG - 2018-03-20 13:49:12 --> No URI present. Default controller set.
DEBUG - 2018-03-20 13:49:13 --> No URI present. Default controller set.
ERROR - 2018-03-20 13:49:57 --> 404 Page Not Found: Views/guide
ERROR - 2018-03-20 14:00:46 --> 404 Page Not Found: Services/login.php
ERROR - 2018-03-20 14:11:02 --> 404 Page Not Found: Services/login.php
ERROR - 2018-03-20 14:14:41 --> 404 Page Not Found: Services/services
DEBUG - 2018-03-20 14:15:59 --> No URI present. Default controller set.
ERROR - 2018-03-20 14:16:47 --> 404 Page Not Found: Services/services
DEBUG - 2018-03-20 14:22:49 --> No URI present. Default controller set.
DEBUG - 2018-03-20 16:08:53 --> No URI present. Default controller set.
DEBUG - 2018-03-20 16:09:36 --> No URI present. Default controller set.
DEBUG - 2018-03-20 16:09:36 --> No URI present. Default controller set.
DEBUG - 2018-03-20 17:45:37 --> No URI present. Default controller set.
DEBUG - 2018-03-20 17:46:22 --> No URI present. Default controller set.
DEBUG - 2018-03-20 17:46:49 --> No URI present. Default controller set.
ERROR - 2018-03-20 17:46:50 --> Query error: Table '.\demo\ci_sessions' is marked as crashed and should be repaired - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = '9880111731a3ff801b53b7b40e8559ec33a2493a'
DEBUG - 2018-03-20 17:47:05 --> No URI present. Default controller set.
ERROR - 2018-03-20 17:47:06 --> Query error: Table '.\demo\ci_sessions' is marked as crashed and should be repaired - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = '9880111731a3ff801b53b7b40e8559ec33a2493a'
DEBUG - 2018-03-20 17:48:40 --> No URI present. Default controller set.
ERROR - 2018-03-20 17:48:40 --> Query error: Table '.\demo\ci_sessions' is marked as crashed and should be repaired - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = '9880111731a3ff801b53b7b40e8559ec33a2493a'
DEBUG - 2018-03-20 17:48:46 --> No URI present. Default controller set.
ERROR - 2018-03-20 17:48:46 --> Query error: Table '.\demo\ci_sessions' is marked as crashed and should be repaired - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = '9880111731a3ff801b53b7b40e8559ec33a2493a'
DEBUG - 2018-03-20 17:53:03 --> No URI present. Default controller set.
ERROR - 2018-03-20 17:53:03 --> Query error: Table '.\demo\ci_sessions' is marked as crashed and should be repaired - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = '9880111731a3ff801b53b7b40e8559ec33a2493a'
DEBUG - 2018-03-20 17:56:31 --> No URI present. Default controller set.
ERROR - 2018-03-20 17:57:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0' at line 1 - Invalid query: 0
ERROR - 2018-03-20 18:00:23 --> Severity: Notice --> Array to string conversion C:\wamp64\www\guidefindernew\application\controllers\Services.php 109
ERROR - 2018-03-20 18:00:23 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$Array C:\wamp64\www\guidefindernew\application\controllers\Services.php 109
ERROR - 2018-03-20 18:07:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0' at line 1 - Invalid query: 0
ERROR - 2018-03-20 18:10:22 --> Severity: Notice --> Array to string conversion C:\wamp64\www\guidefindernew\application\controllers\Services.php 105
ERROR - 2018-03-20 18:19:46 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('uehrfkueukyh', 'jahsdj@gmail.com', NULL, 123.23, 123.23, NULL)
ERROR - 2018-03-20 18:20:51 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('uehrfkueukyh', 'jahsdj@gmail.com', NULL, 123.23, 123.23, NULL)
ERROR - 2018-03-20 18:26:02 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('uehrfkueukyh', 'jahsdj@gmail.com', NULL, 123.23, 123.23, NULL)
ERROR - 2018-03-20 19:04:24 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('uehrfkueukyh', 'jahsdj@gmail.com', NULL, 123.23, 123.23, NULL)
DEBUG - 2018-03-20 19:05:23 --> No URI present. Default controller set.
DEBUG - 2018-03-20 19:05:23 --> No URI present. Default controller set.
ERROR - 2018-03-20 19:09:02 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('gfsf', 'fsda@gmail.com', NULL, 654634.78, 435355, NULL)
ERROR - 2018-03-20 19:11:06 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('gfsf', 'fsda@gmail.com', NULL, 654634.78, 435355, NULL)
ERROR - 2018-03-20 19:12:07 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('Aayush', 'asash@gmail.com', NULL, 111.11, 111.11, NULL)
ERROR - 2018-03-20 19:13:47 --> Query error: Unknown column 'num' in 'field list' - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `num`, `lng`, `lat`, `pass`) VALUES ('Aayush', 'arbaazali.2012@rediff.com', NULL, 11.11, 11.11, NULL)
ERROR - 2018-03-20 19:18:05 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('Aayush', 'arbaazali.2012@rediff.com', NULL, 11.11, 11.11, NULL)
ERROR - 2018-03-20 19:18:58 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('aaaaa', 'asdfasdf@gmail.com', NULL, 11.11, 11.11, NULL)
ERROR - 2018-03-20 19:20:28 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('sadasda', 'asdas@gmaua.com', NULL, 11.11111, 11.11, NULL)
ERROR - 2018-03-20 19:21:53 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('asdasdasda', 'ASDASD@GMAIL.COM', NULL, 11.11, 11.11, NULL)
ERROR - 2018-03-20 19:24:46 --> Query error: Column 'number' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('RESFEDSDF', 'FDSFD@GGVB.CKN', NULL, 11.11, 11.11, NULL)
ERROR - 2018-03-20 19:26:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '111111, `lng`, `lat`, `awdfasdf`) VALUES ('awsdasdas', 'ASDASD@GMAIL.COM', NULL,' at line 1 - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, 111111, `lng`, `lat`, `awdfasdf`) VALUES ('awsdasdas', 'ASDASD@GMAIL.COM', NULL, 1111.111, 11.11, NULL)
ERROR - 2018-03-20 19:31:02 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `ci_providers` (`name`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('asdasdasd', 'ASDASD@GMAIL.COM', NULL, 12.1212, 12.121, NULL)
ERROR - 2018-03-20 19:32:22 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `ci_providers` (`name`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('asdasdasd', 'ASDASD@GMAIL.COM', NULL, 12.1212, 12.121, NULL)
ERROR - 2018-03-20 19:32:56 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `ci_providers` (`name`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('ASDASD', 'asdfasdf@gmail.com', NULL, 110111, 11.111, NULL)
ERROR - 2018-03-20 19:50:31 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `ci_providers` (`name`, `email`, `number`, `lng`, `lat`, `password`) VALUES (NULL, 'sdfasdf@gmak.com', NULL, 11.111, 11.11, NULL)
ERROR - 2018-03-20 19:51:50 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `ci_providers` (`name`, `email`, `number`, `lng`, `lat`, `password`) VALUES (NULL, 'DMFNKLASDD@GMAKI.CKM', NULL, 11.11, 11.11, NULL)
ERROR - 2018-03-20 19:55:27 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('aazaza', 'bvhasjJK@DKLAJSDKLF.COM', '1111111111', 15.22, 12.11, '123456')
ERROR - 2018-03-20 19:56:11 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`) VALUES ('aazaza', 'bvhasjJK@gmail.com', '111111111', 15.22, 12.11, '123456')
DEBUG - 2018-03-20 19:56:55 --> No URI present. Default controller set.
ERROR - 2018-03-20 20:02:23 --> Query error: Column 'service_id' cannot be null - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`, `service_id`) VALUES ('Aa', 'Aa@om.com', '1111111111', 11.11, 11.11, '1111', NULL)
ERROR - 2018-03-20 20:12:21 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`, `service_id`) VALUES ('sdf', 'SDFSD@SAKDFJKS.CM', '65456454546', 223.25, 12.12, '46556454545562', '2')
ERROR - 2018-03-20 20:13:37 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`, `service_id`) VALUES ('JKHASJKDAH', 'kjsdfjhasjkhndfklhlhWsndjfnsjndf@jmsndfm.com', '1111111119', 45.67, 12.34, '1111', '2')
ERROR - 2018-03-20 20:28:45 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `ci_providers` (`fullname`, `email`, `number`, `lng`, `lat`, `password`, `service_id`) VALUES ('DSKLFJSLKDFLasdasd', 'ksdmfkajasdakm@gmaskl.com', '1111111111', 1111.11, 111.11, '11', '1')
ERROR - 2018-03-20 21:56:29 --> 404 Page Not Found: Services/service
DEBUG - 2018-03-20 21:57:05 --> No URI present. Default controller set.
DEBUG - 2018-03-20 22:27:31 --> No URI present. Default controller set.
DEBUG - 2018-03-20 23:37:54 --> No URI present. Default controller set.
DEBUG - 2018-03-20 23:37:55 --> No URI present. Default controller set.
DEBUG - 2018-03-20 23:38:58 --> No URI present. Default controller set.
