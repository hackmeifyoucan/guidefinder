<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-05-10 16:16:09 --> No URI present. Default controller set.
DEBUG - 2018-05-10 16:16:44 --> No URI present. Default controller set.
DEBUG - 2018-05-10 17:41:51 --> No URI present. Default controller set.
DEBUG - 2018-05-10 18:01:28 --> No URI present. Default controller set.
DEBUG - 2018-05-10 18:03:19 --> No URI present. Default controller set.
