<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-19 10:09:42 --> No URI present. Default controller set.
DEBUG - 2018-03-19 10:09:43 --> No URI present. Default controller set.
ERROR - 2018-03-19 10:14:33 --> Query error: Incorrect parameter count in the call to native function 'radians' - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://maps.google.com/mapfiles/ms/icons/green.png' AS icon,
    ( 6371 * acos( cos( radians() ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians() ) + sin( radians() ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = 1
    HAVING distance <= 10
    ORDER BY distance ASC
      
ERROR - 2018-03-19 10:24:13 --> 404 Page Not Found: Services/index.php
ERROR - 2018-03-19 10:24:20 --> 404 Page Not Found: Services/guide
DEBUG - 2018-03-19 10:28:12 --> No URI present. Default controller set.
DEBUG - 2018-03-19 10:28:12 --> No URI present. Default controller set.
DEBUG - 2018-03-19 12:31:26 --> No URI present. Default controller set.
DEBUG - 2018-03-19 12:45:00 --> No URI present. Default controller set.
DEBUG - 2018-03-19 14:41:04 --> No URI present. Default controller set.
DEBUG - 2018-03-19 14:41:15 --> No URI present. Default controller set.
DEBUG - 2018-03-19 14:41:19 --> No URI present. Default controller set.
DEBUG - 2018-03-19 14:49:49 --> No URI present. Default controller set.
DEBUG - 2018-03-19 18:01:31 --> No URI present. Default controller set.
ERROR - 2018-03-19 18:09:09 --> Severity: Notice --> Undefined property: stdClass::$service_id C:\wamp64\www\guidefindernew\application\controllers\Services.php 195
ERROR - 2018-03-19 18:09:09 --> Severity: Notice --> Undefined variable: key C:\wamp64\www\guidefindernew\application\controllers\Services.php 203
ERROR - 2018-03-19 18:09:09 --> Query error: Column 'service_id' cannot be null - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `reciever_id`, `service_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', '2147483647', '3', NULL)
ERROR - 2018-03-19 18:13:06 --> Severity: Notice --> Undefined property: stdClass::$service_id C:\wamp64\www\guidefindernew\application\controllers\Services.php 195
ERROR - 2018-03-19 18:13:06 --> Severity: Notice --> Undefined variable: key C:\wamp64\www\guidefindernew\application\controllers\Services.php 203
ERROR - 2018-03-19 18:13:06 --> Query error: Column 'service_id' cannot be null - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `reciever_id`, `service_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', '2147483647', '3', NULL)
ERROR - 2018-03-19 18:14:58 --> Severity: Warning --> Missing argument 2 for Services::request_guide() C:\wamp64\www\guidefindernew\application\controllers\Services.php 183
ERROR - 2018-03-19 18:14:58 --> Severity: Notice --> Undefined property: stdClass::$service_id C:\wamp64\www\guidefindernew\application\controllers\Services.php 195
ERROR - 2018-03-19 18:14:58 --> Severity: Notice --> Undefined variable: key C:\wamp64\www\guidefindernew\application\controllers\Services.php 203
ERROR - 2018-03-19 18:14:58 --> Query error: Column 'service_id' cannot be null - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `reciever_id`, `service_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', '2147483647', '3', NULL)
ERROR - 2018-03-19 18:44:00 --> Severity: Notice --> Undefined variable: e C:\wamp64\www\guidefindernew\application\controllers\Services.php 202
ERROR - 2018-03-19 18:44:00 --> Query error: Column 'service_id' cannot be null - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `reciever_id`, `service_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', '2147483647', '2', NULL)
ERROR - 2018-03-19 18:51:01 --> Severity: Warning --> Missing argument 2 for Services::request_guide() C:\wamp64\www\guidefindernew\application\controllers\Services.php 183
ERROR - 2018-03-19 18:51:01 --> Severity: Notice --> Undefined variable: k C:\wamp64\www\guidefindernew\application\controllers\Services.php 202
ERROR - 2018-03-19 18:51:01 --> Query error: Column 'service_id' cannot be null - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `reciever_id`, `service_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', '2147483647', '2', NULL)
DEBUG - 2018-03-19 18:54:16 --> No URI present. Default controller set.
DEBUG - 2018-03-19 18:54:24 --> No URI present. Default controller set.
DEBUG - 2018-03-19 18:54:43 --> No URI present. Default controller set.
DEBUG - 2018-03-19 20:32:02 --> No URI present. Default controller set.
DEBUG - 2018-03-19 20:46:48 --> No URI present. Default controller set.
DEBUG - 2018-03-19 20:46:58 --> No URI present. Default controller set.
DEBUG - 2018-03-19 20:47:03 --> No URI present. Default controller set.
ERROR - 2018-03-19 20:47:16 --> Query error: Unknown column 'session_id' in 'field list' - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `reciever_id`, `session_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', '2147483647', '3', '2147483647')
ERROR - 2018-03-19 20:47:58 --> Query error: Unknown column 'session_id' in 'field list' - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `reciever_id`, `session_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', '2147483647', '3', '2147483647')
ERROR - 2018-03-19 20:48:07 --> Query error: Unknown column 'session_id' in 'field list' - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `reciever_id`, `session_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', '2147483647', '3', '2147483647')
ERROR - 2018-03-19 20:48:48 --> Query error: Unknown column 'session_id' in 'field list' - Invalid query: INSERT INTO `requests` (`name`, `email`, `phone`, `reciever_id`, `session_id`) VALUES ('faisal ahmed', 'faisalahmed.vgu@gmail.com', '2147483647', '3', '2147483647')
DEBUG - 2018-03-19 22:49:32 --> No URI present. Default controller set.
