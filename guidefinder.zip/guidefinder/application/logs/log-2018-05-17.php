<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-05-17 10:17:45 --> No URI present. Default controller set.
DEBUG - 2018-05-17 10:17:53 --> No URI present. Default controller set.
