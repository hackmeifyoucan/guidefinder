<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-22 09:29:48 --> No URI present. Default controller set.
ERROR - 2018-03-22 09:31:44 --> Query error: Incorrect parameter count in the call to native function 'radians' - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://aayushvarshney.com/GeeknGineers/marker.png' AS icon,
    ( 6371 * acos( cos( radians() ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians() ) + sin( radians() ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = 2
    HAVING distance <= 10
    ORDER BY distance ASC
      
ERROR - 2018-03-22 09:35:53 --> Query error: Incorrect parameter count in the call to native function 'radians' - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://aayushvarshney.com/GeeknGineers/marker.png' AS icon,
    ( 6371 * acos( cos( radians() ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians() ) + sin( radians() ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = 2
    HAVING distance <= 10
    ORDER BY distance ASC
      
ERROR - 2018-03-22 09:35:57 --> Query error: Incorrect parameter count in the call to native function 'radians' - Invalid query: SELECT 
    fullname,
    CONCAT(ci_providers.user_id,',',ServiceDesc) AS dscr,
    CONCAT(lat,',', lng) as pos,'http://aayushvarshney.com/GeeknGineers/marker.png' AS icon,
    ( 6371 * acos( cos( radians() ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) - radians() ) + sin( radians() ) * sin( radians( `lat` ) ) ) ) AS distance,
    user_id
    FROM ci_providers
    INNER JOIN ci_services  ON ci_services.ServiceId = ci_providers.service_id
    AND ci_services.ServiceId = 2
    HAVING distance <= 10
    ORDER BY distance ASC
      
