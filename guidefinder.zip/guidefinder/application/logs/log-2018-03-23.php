<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-23 05:17:30 --> No URI present. Default controller set.
DEBUG - 2018-03-23 05:17:32 --> No URI present. Default controller set.
