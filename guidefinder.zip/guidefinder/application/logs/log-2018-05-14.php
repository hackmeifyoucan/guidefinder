<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-05-14 11:43:41 --> No URI present. Default controller set.
