<?php

/** @property services_model $services_model *
<!--- Developed By Faisal Ahmed href="https://www.linkedin.com/in/faisal-ahmed-ba895713a/"-->
 */
class Guide extends Front_end
{
	//this function will redirect to guide login page
	function guidelogin()
	{
	
    	$this->view('guide/login');

		
	}
	
	//this function will redirect to guide signup page
	function guidesignup()
	{
		$this->view('guide/register');
		
	}
	
	//this function will redirect to guide reset password page
	function guidereset()
	{
		
		$this->view('guide/forgot-password');
		
	}
	
	//this function will redirect to guide index page
	function guideindex()
	{
	
		 if ($email = $this->session->userdata('guide'))
		 {
		    $sql = "SELECT r.request_id as request_no,r.name as 'request name',r.email as email,r.phone as phone,re.fullname as 'Rec name' from requests r, ci_providers re WHERE re.user_id = r.reciever_id and re.email = '".$email."'";
		    $query = $this->db->query($sql);
		    $result = $query->result_array();
     	    $data = array(
			'result' => $result
	     	);
		    $this->view('guide/index',$data);
        }
          else
		  {	
         	  redirect('guide/guidelogin');            		
		  }
	}
	

	//function insert_data_guide (Guide Sign Up)
	function insert_data_guide()
	{
		$data = array(
	    'fullname' => $this->input->post('fullname'),
        'email' => $this->input->post('email'),
        'number' => $this->input->post('number'),
        'lng' => (float)$this->input->post('lng'),
		'lat' => (float)$this->input->post('lat'),
		'password' => $this->input->post('password'),
		'service_id' => $this->input->post('Service_type')
        );
        //Transfering data to Model
        $this->db->insert("ci_providers",$data);
        $data['message'] = 'Data Inserted Successfully';
	}
	
	//fatching data for guide login and generating session
	function read_data_guide()
	{
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		
		$this->db->from('ci_providers');
	    $this->db->where('email',$email);
		$this->db->where('password',$password);
		$res=$this->db->get()->result();
		
		
		if(count($res)>0)
		
		{
		  $session_data= $email;
		  $user_id=$res[0]->user_id;
		  $this->session->set_userdata('guide',$session_data);
		  redirect("guide/guideindex");
          
		}
			else
		{
			echo "SORRY";
		}
	}
	
	//destroy session for guide dashboard
	
	function close_session_guide()
    {
		
     $this->session->sess_destroy();
     	 
	 redirect ("guide/guidelogin");	 
    }
	
	
	
	//Display requests in table
	function table_requests()
	{
		
		$this->view('guide/tables');
	
	}
}
/* End of file guide.php  <!--- Developed By Faisal Ahmed href="https://www.linkedin.com/in/faisal-ahmed-ba895713a/"-->*/

/* Location: ./application/controllers/Guide.php */