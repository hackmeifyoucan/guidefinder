<?php $this->load->view('theme/header'); ?>
<?php //$this->load->view('theme/rmenu'); ?>
<?php $this->load->view($main_content); ?>
<?php $this->load->view('theme/footer'); ?>