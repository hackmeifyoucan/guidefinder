<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Packages</title>
  
  
  
      <link rel="stylesheet" href="https://codepen.io/Homebom/pen/RNKMrL.css">
      <link rel="stylesheet" href="https://codepen.io/Homebom/pen/RNKMrL.scss">
	  <link href="https://fonts.googleapis.com/css?family=Aclonica" rel="stylesheet">

  
</head>

<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 0px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>

<body>

  <figure class="intro">
  <img src="http://banktellerinterviewquestions.com/wp-content/uploads/2012/07/contact-us-image.jpg" alt="" />
  <figcaption class="caption">
    <h1 style="font-family: 'Aclonica', sans-serif;"></h1>
  </figcaption>
  <span class="overlay">
<svg version="1.1" id="circle" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 500 250" enable-background="new 0 0 500 250" xml:space="preserve" PreserveAspectRatio="none">
<path fill="#FFFFFF" d="M250,246.5c-97.85,0-186.344-40.044-250-104.633V250h500V141.867C436.344,206.456,347.85,246.5,250,246.5z"
	/>
</svg>
  </span>
</figure>
<article class="copy">
  <h1> 
      <b>We would like to here from you.</b></h1>
	  <h2> Contact Us Here.</h2><br>
       <p> Phone: +91 68245-*******</p>
	   <p> Email: email@email.com</p>
<p align="center"> <b>Disclaimer: The content mentioned above is just a fictionary data.</b></p>
</article>


  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  

    <script  src="https://codepen.io/Homebom/pen/RNKMrL.js"></script>



</body>

 

</html>
