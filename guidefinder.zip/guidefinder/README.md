# tutorial LINK #
[Codeigniter google maps geolocation integration](http://webeasystep.com/blog/view_article/Codeigniter_google_maps_geolocation_integration)

# video LINK #
[Google maps Geolocation Codeigniter Full Script](https://www.youtube.com/watch?v=mT_2rNjCZN4)

[Integrate Google Maps, Places, and Geocoding APIs with PHP](https://www.youtube.com/watch?v=IozIX9htOcI)